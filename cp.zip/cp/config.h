
//This is the configuration file for C'

/////////////////////////////////////////////////////////////////////
//Add some macros to compile your code

//#define _M_IX86 400
//#define WIN32
//#define __STDC__ 0
//#define _WIN32
//#define _RELEASE
//#define _CONSOLE
//#define _UNICODE
//#define UNICODE

//#define _M_IX86

/////////////////////////////////////////////////////////////////////
//Make some compiler extensions from other compilers macros

//#define __stdcall
//#define __fastcall
//#define __pragma(x)  
//#define __inline  
//#define  __cdecl  
//#define __declspec(x)          
//#define __int64 long long
//#define _MSC_VER  1300
//#define __ptr64

/////////////////////////////////////////////////////////////////////
//Add your include directories here (sample)

//#pragma dir "c:\Program Files (x86)\Windows Kits\10\Include\10.0.14393.0\shared"
//#pragma dir "c:\Program Files (x86)\Windows Kits\10\Include\10.0.14393.0\um"
//#pragma dir "c:\Program Files (x86)\Windows Kits\10\Include\10.0.14393.0\ucrt" 
//#pragma dir "c:\Program Files (x86)\Microsoft Visual Studio\2017\Community\VC\Tools\MSVC\14.10.25017\include"

